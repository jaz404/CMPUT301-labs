// Code written by Jaspreet Singh Chhabra, jchhabr1
// Listy City 5
// Lab 5


package com.example.listycity5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;


import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Nullable;

public class MainActivity extends AppCompatActivity {
    ListView cityList;
    ArrayList<City> cityDataList;
    CityArrayAdapter cityArrayAdapter;
    private Button addCityButton;
    private Button deleteCityButton;
    private EditText addCityEditText;
    private EditText addProvinceEditText;

    private FirebaseFirestore db;
    private CollectionReference citiesRef;


    private int lastSelectedPosition = ListView.INVALID_POSITION;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cityList = findViewById(R.id.city_list);

        addCityEditText = findViewById(R.id.city_name_edit);
        addProvinceEditText = findViewById(R.id.province_name_edit);
        addCityButton = findViewById(R.id.add_city_button);
        deleteCityButton = findViewById(R.id.delete_city_button);

        deleteCityButton.setEnabled(false);

        db = FirebaseFirestore.getInstance();

        citiesRef = db.collection("cities");

        cityDataList = new ArrayList<>();

        //addCitiesInit();

        cityArrayAdapter = new CityArrayAdapter(this, cityDataList);
        cityList.setAdapter(cityArrayAdapter);
        citiesRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot querySnapshots,
                                @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("Firestore", error.toString());
                    return;
                }
                if (querySnapshots != null) {
                    cityDataList.clear();
                    for (QueryDocumentSnapshot doc: querySnapshots) {
                        String city = doc.getId();
                        String province = doc.getString("Province");
                        Log.d("Firestore", String.format("City(%s, %s) fetched", city,
                                province));
                        cityDataList.add(new City(city, province));
                    }
                }
            }
        });
        addCityButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String city = addCityEditText.getText().toString();
                 String province = addProvinceEditText.getText().toString();
//
//                 // Create a new City object
                 City newCity = new City(city, province);
                 addNewCity(newCity);
                 addCityEditText.setText("");
                 addProvinceEditText.setText("");
             }
        });

        cityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        // get the position of the item clicked
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                lastSelectedPosition = position;
                deleteCityButton.setEnabled(true);
                // only enable delete button if a city is selected

            }
        });

        deleteCityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastSelectedPosition != ListView.INVALID_POSITION) {
                    // Retrieve the selected city from the datalist
                    City selectedCity = cityDataList.get(lastSelectedPosition);

                    // Delete the selected city document from Firebase
                    citiesRef.document(selectedCity.getCityName()).delete();}
                    cityArrayAdapter.notifyDataSetChanged();

            }
        });



    }

    /**
     * Adds the initial city objects to the ArrayList
     */

//    private void addCitiesInit() {
//        String []cities ={"Edmonton", "Vancouver", "Toronto", "Hamilton", "Denver", "Los Angeles"};
//        String []provinces = {"AB", "BC", "ON", "ON", "CO", "CA"};
//        for(int i=0;i<cities.length;i++){
//            cityDataList.add((new City(cities[i], provinces[i])));
//        }
//    }
    private void addNewCity(City city) {
        HashMap<String, String> data = new HashMap<>();
        data.put("Province", city.getProvinceName());
        citiesRef.document(city.getCityName()).set(data);
        cityArrayAdapter.notifyDataSetChanged();

    }
}